@file:OptIn(InternalResourceApi::class)

package edu.ucb.ds.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.FontResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/edu.ucb.ds.resources/"

@delegate:ResourceContentHash(543_882_501)
internal val Res.font.fira_sans_bold: FontResource by lazy {
      FontResource("font:fira_sans_bold", setOf(
        ResourceItem(setOf(), "${MD}font/fira_sans_bold.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_142_485_705)
internal val Res.font.fira_sans_medium: FontResource by lazy {
      FontResource("font:fira_sans_medium", setOf(
        ResourceItem(setOf(), "${MD}font/fira_sans_medium.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-263_817_272)
internal val Res.font.fira_sans_regular: FontResource by lazy {
      FontResource("font:fira_sans_regular", setOf(
        ResourceItem(setOf(), "${MD}font/fira_sans_regular.ttf", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_007_430_937)
internal val Res.font.fira_sans_semibold: FontResource by lazy {
      FontResource("font:fira_sans_semibold", setOf(
        ResourceItem(setOf(), "${MD}font/fira_sans_semibold.ttf", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainFont0Resources(map: MutableMap<String, FontResource>) {
  map.put("fira_sans_bold", Res.font.fira_sans_bold)
  map.put("fira_sans_medium", Res.font.fira_sans_medium)
  map.put("fira_sans_regular", Res.font.fira_sans_regular)
  map.put("fira_sans_semibold", Res.font.fira_sans_semibold)
}
